# gaana.com
Replica of ganna.com completely developed by me.


<a href="https://hkgannaapp.herokuapp.com/"><h1>hkganna.com</h1></a>








added features:-
1.drag and drop feature
2.Single Page Application
3.offline Song page/playlist-page developement by javascript 
